#ifndef _STRING_H
#define _STRING_H

/*****************************************************************
 * -*- c -*-
 * $RCSfile$
 *
 * Copyright (C) 1994, 1995 by Sony Computer Entertainment Inc.
 * All Rights Reserved.
 *
 * Sony Computer Entertainment Inc. R & D Division
 *
 * $Id$
 *
 *****************************************************************/
/*
 * $PSLibId: Run-time Library Release 4.7$
 */

#include <strings.h>

/* ----------------------------------------------------------------
 *	End on File
 * ---------------------------------------------------------------- */
#endif /* _STRING_H_ */
/* DON'T ADD STUFF AFTER THIS */
