/*
 * romio.h
 *
 * rom monitor i/o
 */
/*
 * $PSLibId: Run-time Library Release 4.7$
 */

#ifndef _ROMIO_H
#define _ROMIO_H

#include <sys/file.h>

#endif /* _ROMIO_H */
